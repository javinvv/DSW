package es.cifpcesarmanrique.musicmanager.services;
import es.cifpcesarmanrique.musicmanager.models.Album;
import es.cifpcesarmanrique.musicmanager.repositories.AlbumRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class AlbumService {
    private final AlbumRepository albumRepository;

    public AlbumService(AlbumRepository albumRepository) { this.albumRepository = albumRepository; }

    public List<Album> obtenerAlbumes() {
         return albumRepository.findAll();
    }

    public Album findById(Integer id) { return albumRepository.findById(id).orElse(null); }
    public void save(Album album) { albumRepository.save(album); }
    public void delete(Integer id) { albumRepository.deleteById(id); }
    public List<Album> findByArtistId(Integer artistId) { return albumRepository.findByArtistId(artistId); }
}