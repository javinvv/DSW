package es.cifpcesarmanrique.musicmanager.repositories;
import es.cifpcesarmanrique.musicmanager.models.Album;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface AlbumRepository extends JpaRepository<Album, Integer> {
    List<Album> findAll();
    List<Album> findByArtistId(Integer artistId);
}