package es.cifpcesarmanrique.musicmanager.services;

import es.cifpcesarmanrique.musicmanager.models.Review;
import es.cifpcesarmanrique.musicmanager.repositories.ReviewRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ReviewService {
    private final ReviewRepository reviewRepository;

    public ReviewService(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    public List<Review> findByArtistId(int artistId) {
        return reviewRepository.findByArtistId(artistId);
    }

    public void guardar(Review review) {
        reviewRepository.save(review);
    }
}