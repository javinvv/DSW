package es.cifpcesarmanrique.musicmanager.services;

import es.cifpcesarmanrique.musicmanager.models.Track;
import es.cifpcesarmanrique.musicmanager.repositories.TrackRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrackService {

    private final TrackRepository trackRepository;

    public TrackService(TrackRepository trackRepository) {
        this.trackRepository = trackRepository;
    }

    // Buscar todas las canciones
    public List<Track> findAll() {
        return trackRepository.findAll();
    }

    // Buscar una canción por su ID
    public Track findById(Integer id) {
        return trackRepository.findById(id).orElse(null);
    }

    // Buscar canciones que pertenecen a un álbum específico (útil para la vista de detalles del disco)
    public List<Track> findByAlbumId(Integer albumId) {
        return trackRepository.findByAlbumId(albumId);
    }

    // Guardar o actualizar una canción
    public void guardar(Track track) {
        trackRepository.save(track);
    }

    // Eliminar una canción por su ID
    public void eliminar(Integer id) {
        trackRepository.deleteById(id);
    }
}