package es.cifpcesarmanrique.musicmanager.repositories;
import es.cifpcesarmanrique.musicmanager.models.Artist;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ArtistRepository extends JpaRepository<Artist, Integer> {
    List<Artist> findAllBy(Pageable pageable);
}