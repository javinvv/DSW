package es.cifpcesarmanrique.musicmanager.repositories;
import es.cifpcesarmanrique.musicmanager.models.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Integer> {
    List<Review> findByArtistId(Integer artistId);
}