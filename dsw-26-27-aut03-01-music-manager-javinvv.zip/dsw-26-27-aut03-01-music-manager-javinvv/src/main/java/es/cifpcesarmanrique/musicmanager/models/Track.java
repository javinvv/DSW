package es.cifpcesarmanrique.musicmanager.models;

import jakarta.persistence.*;

@Entity
@Table(name = "Track")
public class Track {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TrackId")
    private Integer id;

    @Column(name = "Name")
    private String name;

    @Column(name = "AlbumId")
    private Integer albumId;

    @ManyToOne
    @JoinColumn(name = "AlbumId", insertable = false, updatable = false)
    private Album album;

    public Track() {}

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getAlbumId() { return albumId; }
    public void setAlbumId(Integer albumId) { this.albumId = albumId; }
    public Album getAlbum() { return album; }
    public void setAlbum(Album album) { this.album = album; }
}