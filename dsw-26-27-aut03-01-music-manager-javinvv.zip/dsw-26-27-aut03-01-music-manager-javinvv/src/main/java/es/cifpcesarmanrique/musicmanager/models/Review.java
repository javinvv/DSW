package es.cifpcesarmanrique.musicmanager.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "Review")
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ReviewId")
    private Integer id;

    @NotEmpty(message = "El título es necesario")
    @Size(min = 3, max = 10, message = "El título debe tener entre 3 y 10 caracteres")
    @Column(name = "Title")
    private String title;

    @NotEmpty(message = "La descripción es obligatoria")
    @Size(min = 5, max = 30, message = "La descripción debe tener entre 5 y 30 caracteres")
    @Column(name = "Description")
    private String description;

    @Min(value = 1, message = "La valoración mínima es 1")
    @Max(value = 5, message = "La valoración máxima es 5")
    @Column(name = "Rating")
    private Integer rating;

    @Column(name = "ArtistId")
    private Integer artistId;

    @ManyToOne
    @JoinColumn(name = "ArtistId", insertable = false, updatable = false)
    private Artist artist;

    public Review() {}

    public Review(String title, String description, Integer rating, Integer artistId) {
        this.title = title;
        this.description = description;
        this.rating = rating;
        this.artistId = artistId;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Integer getRating() { return rating; }
    public void setRating(Integer rating) { this.rating = rating; }
    public Integer getArtistId() { return artistId; }
    public void setArtistId(Integer artistId) { this.artistId = artistId; }
    public Artist getArtist() { return artist; }
    public void setArtist(Artist artist) { this.artist = artist; }
}