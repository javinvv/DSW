package es.cifpcesarmanrique.musicmanager.services;
import es.cifpcesarmanrique.musicmanager.models.Artist;
import es.cifpcesarmanrique.musicmanager.repositories.ArtistRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ArtistService {
    private final ArtistRepository artistRepository;

    public ArtistService(ArtistRepository artistRepository) { this.artistRepository = artistRepository; }

    public List<Artist> obtenerArtistas() {
        return artistRepository.findAll();
    }

    public Artist findById(Integer id) { return artistRepository.findById(id).orElse(null); }
    public void save(Artist artist) { artistRepository.save(artist); }
    public void delete(Integer id) { artistRepository.deleteById(id); }
}