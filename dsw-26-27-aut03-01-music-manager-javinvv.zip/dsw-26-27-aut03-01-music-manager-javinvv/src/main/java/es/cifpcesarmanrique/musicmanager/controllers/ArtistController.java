package es.cifpcesarmanrique.musicmanager.controllers;

import es.cifpcesarmanrique.musicmanager.models.Album;
import es.cifpcesarmanrique.musicmanager.models.Artist;
import es.cifpcesarmanrique.musicmanager.models.Review;
import es.cifpcesarmanrique.musicmanager.services.AlbumService;
import es.cifpcesarmanrique.musicmanager.services.ArtistService;
import es.cifpcesarmanrique.musicmanager.services.ReviewService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/artists")
public class ArtistController {
    private final ArtistService artistService;
    private final ReviewService reviewService;
    private final AlbumService albumService;

    public ArtistController(ArtistService artistService, ReviewService reviewService, AlbumService albumService) {
        this.artistService = artistService;
        this.reviewService = reviewService;
        this.albumService = albumService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("artists", artistService.obtenerArtistas());
        return "artistas";
    }

    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("artist", new Artist());
        return "crear";
    }

    @PostMapping("/create")
    public String create(@Valid @ModelAttribute Artist artist, BindingResult result) {
        if (result.hasErrors()) return "artists/create";
        artistService.save(artist);
        return "redirect:/artistas";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Integer id, Model model) {
        Artist artist = artistService.findById(id);
        if (artist == null) return "redirect:/artists";
        model.addAttribute("artist", artist);
        return "edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable Integer id, @Valid @ModelAttribute Artist artist, BindingResult result) {
        if (result.hasErrors()) return "artists/edit";
        artist.setId(id);
        artistService.save(artist);
        return "redirect:/artistas";
    }

    @GetMapping("/details/{id}")
    public String details(@PathVariable Integer id, Model model) {
        Artist artist = artistService.findById(id);
        if (artist == null) return "redirect:/artists";
        model.addAttribute("artist", artist);
        model.addAttribute("reviews", reviewService.findByArtistId(id));
        return "details";
    }

    @GetMapping("/delete/{id}")
    public String deleteConfirm(@PathVariable Integer id, Model model) {
        Artist artist = artistService.findById(id);
        if (artist == null) return "redirect:/artists";
        model.addAttribute("artist", artist);
        return "delete";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Integer id) {
        artistService.delete(id);
        return "redirect:/artistas";
    }

    @GetMapping("/createReview/{artistId}")
    public String createReviewForm(@PathVariable Integer artistId, Model model) {
        Review review = new Review();
        review.setArtistId(artistId);
        model.addAttribute("review", review);
        model.addAttribute("artist", artistService.findById(artistId));
        return "crearReview";
    }

    @PostMapping("/createReview")
    public String createReview(@Valid @ModelAttribute Review review, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("artist", artistService.findById(review.getArtistId()));
            return "crearReview";
        }
        reviewService.guardar(review);
        return "redirect:/details/" + review.getArtistId();
    }

    @GetMapping("/artistAlbums/{id}")
    public String artistAlbums(@PathVariable Integer id, Model model) {
        Artist artist = artistService.findById(id);
        if (artist == null) return "redirect:/artistas";
        model.addAttribute("artist", artist);
        model.addAttribute("albums", albumService.findByArtistId(id));
        return "artistaAlbum";
    }
}