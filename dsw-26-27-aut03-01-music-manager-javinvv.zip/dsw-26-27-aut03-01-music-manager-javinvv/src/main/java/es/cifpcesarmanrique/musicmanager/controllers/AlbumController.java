package es.cifpcesarmanrique.musicmanager.controllers;

import es.cifpcesarmanrique.musicmanager.models.Album;
import es.cifpcesarmanrique.musicmanager.services.AlbumService;
import es.cifpcesarmanrique.musicmanager.services.ArtistService;
import es.cifpcesarmanrique.musicmanager.services.TrackService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/albums")
public class AlbumController {
    private final AlbumService albumService;
    private final ArtistService artistService;
    private final TrackService trackService;

    public AlbumController(AlbumService albumService, ArtistService artistService, TrackService trackService) {
        this.albumService = albumService;
        this.artistService = artistService;
        this.trackService = trackService;
    }

    @GetMapping
    public String Album(Model model) {
        model.addAttribute("albums", albumService.obtenerAlbumes());
        return "discos";
    }

    @GetMapping("/crear")
    public String createForm(Model model) {
        model.addAttribute("album", new Album());
        model.addAttribute("artists", artistService.obtenerArtistas());
        return "crear";
    }

    @PostMapping("/crear")
    public String create(@Valid @ModelAttribute Album album, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("artists", artistService.obtenerArtistas());
            return "crear";
        }
        albumService.save(album);
        return "redirect:albums";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Integer id, Model model) {
        Album album = albumService.findById(id);
        if (album == null) return "redirect:/albums";
        model.addAttribute("album", album);
        model.addAttribute("artists", artistService.obtenerArtistas());
        return "edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable Integer id, @Valid @ModelAttribute Album album, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("artists", artistService.obtenerArtistas());
            return "edit";
        }
        album.setId(id);
        albumService.save(album);
        return "redirect:albums";
    }

    @GetMapping("/details/{id}")
    public String details(@PathVariable Integer id, Model model) {
        Album album = albumService.findById(id);
        if (album == null) return "redirect:/albums";
        model.addAttribute("album", album);
        model.addAttribute("tracks", trackService.findByAlbumId(id));
        return "details";
    }

    @GetMapping("/delete/{id}")
    public String deleteConfirm(@PathVariable Integer id, Model model) {
        Album album = albumService.findById(id);
        if (album == null) return "redirect:/albums";
        model.addAttribute("album", album);
        return "delete";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Integer id) {
        albumService.delete(id);
        return "redirect:albums";
    }
}