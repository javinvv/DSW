package es.cifpcesarmanrique.musicmanager.repositories;
import es.cifpcesarmanrique.musicmanager.models.Track;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TrackRepository extends JpaRepository<Track, Integer> {
    List<Track> findByAlbumId(Integer albumId);
}